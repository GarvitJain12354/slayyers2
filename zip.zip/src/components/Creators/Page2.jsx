import React from "react";

const Page2 = () => {
  return (
    <div className="flex w-full h-fit py-10">
      <h1 className="text-5xl mont font-extrabold text-center w-full">
        Perfect for Creators in Fashion, <br /> Beauty & Lifestyle
      </h1>

    </div>
  );
};

export default Page2;
