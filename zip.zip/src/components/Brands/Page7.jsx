import React from "react";

const Page7 = () => {
  return (
    <div className="w-full max-h-screen flex flex-col items-center mb-10">
      <h1 className="mont text-5xl font-semibold text-center">
        Transforming Fashion Businesses <br /> Across India
      </h1>
    </div>
  );
};

export default Page7;
